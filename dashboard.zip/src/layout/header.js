


import React, { useEffect, useState } from "react";
import styled from "styled-components";

import Gift from "../assets/icons/gift.svg";
import Notification from "../assets/icons/notification.svg"
import logo from "../assets/logo.png";
import profile from "../assets/Profile.png";
import search from "../assets/search.png";
import unitedState from "../assets/unitedState.png";


const ToggleButton = styled.button`
  display: none;

  @media (max-width: 1330px) {
    margin-left: auto; // Align it to the right
    background: none;
    border: none;
    cursor: pointer;
    font-size: 24px;
    display: block; // Show the button on smaller screens
  }
`;

function Header({ toggleSidebar, isOpen }) {
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 1330);

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 1330);
    };

    window.addEventListener("resize", handleResize);

    // Cleanup the event listener on component unmount
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <div className="headerContainer">
      <div className="logoContainer">
        <img src={logo} alt="logo" className="logo" />
        <h1> Dream Event</h1>
      </div>
    
      <div className="profile-container">
        <div className="wrapper">
          <div className="icon"><img src={search} alt="search" /></div>
          <input className="input" placeholder="Search" />
        </div>
        <div className="userOptions">
          <img src={unitedState} alt="united" />
          <select>
            <option  value="en"><h3>ENGLISH</h3> </option>
          </select>
        </div>
        <div className="imageBorder"><img src={Gift} alt="bell" width="24px" height="24px" /></div>
        
        <div className="imageBorder"><img src={Notification} alt="gift"  width="24px" height="24px" /></div> 
        {isMobile && (
        <ToggleButton
          onClick={toggleSidebar}
          aria-expanded={isOpen}
          id="toggle-button"
          aria-controls="sidebar"
        >
          {isOpen ? "✖" : "☰"}
        </ToggleButton>
      )}
          <img src={profile} alt="User Icon" width="50px" height="50px" />
          <div className="profile-content">
            <h3>Minato Namikaze</h3>
            <p className="header-owner">Owner</p>
          </div>
          <div className="event-icons"></div>
      </div>
    </div>
  );
}

export default Header;
