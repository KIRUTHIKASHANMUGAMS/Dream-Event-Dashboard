import React from 'react';

import Create from '../components/createEvent/create';

function createEvent() {
  return (
    <div>
      <Create/>
    </div>
  )
}

export default createEvent
