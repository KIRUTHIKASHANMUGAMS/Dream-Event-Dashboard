import React from 'react';

import  Setting from "../components/setting/setting";

function setting() {
  return (
    <div>
      <Setting />
    </div>
  )
}

export default setting
