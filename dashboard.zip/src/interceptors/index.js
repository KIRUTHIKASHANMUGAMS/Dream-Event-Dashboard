import axios from 'axios';
import Cookies from 'universal-cookie';

import config from '../config';




export function setHeaderToken() {
    const cookies = new Cookies();

    axios.interceptors.request.use(
        config => {
            const token = cookies.get('accessToken');
            if (token) {
                config.headers['Authorization'] = 'Bearer ' + token;
            }

            return config;
        },
        error => {
            return Promise.reject(error);
        }
    );

    axios.interceptors.response.use(
        response => {
            return response;
        },
        async error => {
            if (error.response) {
                const cookies = new Cookies(null, { path: "/" });
                const originalRequest = error.config;
                console.log("originalRequest", originalRequest)
                if (error.response.status === 401) {
                    try {
                        const refreshToken =cookies.get('refreshToken');
                        const response = await axios.post(`${config.refreshTokenUrl}`, { refreshToken });
                        const token = response.data.token;
                        const newRefreshToken = response.data.refreshToken
                        cookies.set('token', token);
                        cookies.set('refreshToken', newRefreshToken);
                        originalRequest.headers.Authorization = `Bearer ${token}`;
                        return axios(originalRequest);
                    } catch (error) {
                        console.log("error", error)
                    }
                }
            } else if (error.request) {
                console.error('Error request:', error.request);
            } else {
                console.error('Error message:', error.message);
            }
            return Promise.reject(error);
        }
    );
}
